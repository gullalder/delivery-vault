# 动效规格表：每个动画按六要素写清，照表执行

六要素：**触发**（什么动作引发）/ **起始**（元素初始状态）/ **运动**（动什么属性）/ **落点**（结束状态）/ **时长** / **缓动**。

总原则：只动 `transform` 与 `opacity`；`prefers-reduced-motion: reduce` 时全部关闭；移动端（≤860px）关视差；任何动画不得阻塞内容阅读（CDN 动画库加载失败时内容必须可见——先写降级兜底再写动画）。

## 现成参数表

### 1. Hero 入场（交错升起）
- 触发：页面加载完成
- 起始：标题组各元素 opacity 0，translateY(44px)
- 运动：依次升起淡入，同组 stagger 间隔 120–140ms
- 落点：opacity 1，translateY(0)
- 时长：单个 0.95–1.1s，整组约 1.6s 完成
- 缓动：power3.out（GSAP）/ cubic-bezier(0.22, 1, 0.36, 1)（CSS）

### 2. 滚动 Reveal（版块淡入）
- 触发：元素进入视口 85% 高度处（IntersectionObserver threshold 或 ScrollTrigger start "top 86%"）
- 起始：opacity 0，translateY(36px)
- 运动：淡入上移，一次性，不重复
- 落点：opacity 1，translateY(0)
- 时长：0.8–0.9s
- 缓动：power3.out / cubic-bezier(0.22, 1, 0.36, 1)
- 同排卡片追加 stagger 100ms

### 3. Hero 视差
- 触发：页面滚动（scrub 跟随）
- 起始：背景图 scale 1.12，y 0
- 运动：背景以内容约 0.35 倍速下沉，yPercent 0 → 12–15
- 落点：hero 滚出视口时停止
- 时长：跟随滚动，无独立时长
- 缓动：线性（scrub）
- 备注：背景容器上下各预留 ≥12% 溢出防露白；≤860px 关闭

### 4. 数字计数器
- 触发：数字条进入视口（一次性）
- 起始：0
- 运动：数值线性递增到目标值（目标值必须是真实数据）
- 落点：目标值定格
- 时长：1.2–1.5s
- 缓动：power2.out（先快后慢收尾）

### 5. CTA 脉冲
- 触发：常驻（仅主 CTA）
- 起始：box-shadow 光晕 30% 强度
- 运动：光晕强度与扩散半径呼吸式涨落
- 落点：回到起始，无限循环
- 时长：单周期 2.4–2.8s
- 缓动：ease-in-out
- 备注：只动阴影不动尺寸，避免布局抖动

### 6. 内容轮播（评价/要点）
- 触发：自动播放 + 点击圆点手动切换
- 起始：当前条 opacity 1，其余 0
- 运动：交叉淡入淡出
- 落点：新条 opacity 1
- 时长：切换 0.7–0.8s；停留 4.5–5s
- 缓动：ease

### 7. 导航吸顶
- 触发：页面滚动 > 24px
- 起始：透明背景
- 运动：背景模糊 + 半透明底色渐显
- 时长：0.3s
- 缓动：ease

## 实现备忘

- GSAP 路线：`gsap + ScrollTrigger`（cdnjs 3.12.x），`gsap.matchMedia()` 按断点开关视差。
- 零依赖路线：CSS transition/animation + IntersectionObserver 加 `.in` 类；计数器用 requestAnimationFrame 手写。
- 两条路线都要有兜底：动画库未加载时，脚本直接给所有 `.reveal` 元素打上可见状态、计数器直接显示目标值。
